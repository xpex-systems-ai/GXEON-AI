require('dotenv').config({ path: require('path').join(__dirname, '../config/secure/.env') });

const { ethers } = require('ethers');

async function sendSepoliaTransaction() {
  console.log('═══════════════════════════════════════════════');
  console.log('  EXECUTOR DE TRANSAÇÃO - SEPOLIA');
  console.log('═══════════════════════════════════════════════\n');

  const RPC_URL = process.env.RPC_URL;
  const PRIVATE_KEY = process.env.WALLET_PRIVATE_KEY;

  if (!RPC_URL || !PRIVATE_KEY) {
    console.error('❌ ERRO: RPC_URL e WALLET_PRIVATE_KEY devem estar configurados no .env');
    process.exit(1);
  }

  console.log('⚠️  MODO: ETHEREUM SEPOLIA TESTNET\n');

  console.log('1️⃣  Conectando ao RPC (Alchemy)...');
  const provider = new ethers.JsonRpcProvider(RPC_URL);

  const network = await provider.getNetwork();
  console.log(`   ✅ Conectado à rede: ${network.name} (Chain ID: ${network.chainId})\n`);

  if (network.chainId !== 1n) {
    console.error('⚠️  ATENÇÃO: Esta não é a Ethereum Mainnet!');
    process.exit(1);
  }

  console.log('2️⃣  Carregando wallet via PRIVATE_KEY...');
  const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
  const fromAddress = wallet.address;
  console.log(`   ✅ Wallet carregada: ${fromAddress}\n`);

  console.log('3️⃣  Verificando saldo...');
  const balance = await provider.getBalance(fromAddress);
  console.log(`   💰 Saldo: ${ethers.formatEther(balance)} ETH\n`);

  const value = ethers.parseEther('0.00001');
  console.log('4️⃣  Montando transação...');
  console.log(`   De: ${fromAddress}`);
  console.log(`   Para: ${fromAddress}`);
  console.log(`   Valor: ${ethers.formatEther(value)} ETH\n`);

  console.log('5️⃣  Estimando gas...');
  const gasEstimate = await provider.estimateGas({
    from: fromAddress,
    to: fromAddress,
    value: value
  });
  console.log(`   ⛽ Gas estimado: ${gasEstimate.toString()} unidades\n`);

  const feeData = await provider.getFeeData();
  const maxFeePerGas = feeData.maxFeePerGas;
  const maxPriorityFeePerGas = feeData.maxPriorityFeePerGas;

  console.log(`   Max Fee: ${ethers.formatUnits(maxFeePerGas, 'gwei')} gwei`);
  console.log(`   Priority Fee: ${ethers.formatUnits(maxPriorityFeePerGas, 'gwei')} gwei\n`);

  console.log('6️⃣  Assinando e enviando transação...');
  const tx = await wallet.sendTransaction({
    to: fromAddress,
    value: value,
    gasLimit: gasEstimate,
    maxFeePerGas: maxFeePerGas,
    maxPriorityFeePerGas: maxPriorityFeePerGas
  });

  console.log(`   📤 Transação enviada!`);
  console.log(`   Hash: ${tx.hash}`);
  console.log(`   Nonce: ${tx.nonce}`);
  console.log(`   Gas Price: ${ethers.formatUnits(tx.gasPrice || maxFeePerGas, 'gwei')} gwei\n`);

  console.log('7️⃣  Aguardando confirmação...');
  const receipt = await tx.wait();
  console.log(`   ✅ Confirmada no bloco: ${receipt.blockNumber}`);
  console.log(`   Gas usado: ${receipt.gasUsed.toString()}`);
  console.log(`   Custo total: ${ethers.formatEther(receipt.gasUsed * (tx.gasPrice || maxFeePerGas))} ETH\n`);

  console.log('═══════════════════════════════════════════════');
  console.log('  ✅ TRANSAÇÃO CONCLUÍDA');
  console.log('═══════════════════════════════════════════════');
  console.log(`  TX HASH: ${tx.hash}`);
  console.log('═══════════════════════════════════════════════');

  return tx.hash;
}

sendSepoliaTransaction()
  .then(hash => {
    console.log('\nFinalizado com sucesso.');
    process.exit(0);
  })
  .catch(error => {
    console.error('\n❌ ERRO:', error.message);
    process.exit(1);
  });
