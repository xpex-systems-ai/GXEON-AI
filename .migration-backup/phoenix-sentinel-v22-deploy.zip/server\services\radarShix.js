import supabase from './supabase.js';
import axios from 'axios';
import { ethers } from 'ethers';
import WebSocket from 'ws';
import dotenv from 'dotenv';

dotenv.config();

// ═══════════════════════════════════════════════════════════════════════════
// SIGNAL PROVIDER INTEGRATION (M2M Alpha Broadcast)
// ═══════════════════════════════════════════════════════════════════════════
class SignalProviderClient {
    constructor() {
        this.ws = null;
        this.signalServerUrl = process.env.SIGNAL_SERVER_URL || 'ws://localhost:8765/ws/radar';
        this.isConnected = false;
        this.reconnectInterval = 5000;
        this.signalsQueued = [];
        this.totalSignalsSent = 0;
    }
    
    connect() {
        if (this.isConnected) return;
        
        try {
            this.ws = new WebSocket(this.signalServerUrl);
            
            this.ws.on('open', () => {
                this.isConnected = true;
                console.log(`📡 [SIGNAL_PROVIDER] Conectado ao Signal Server`);
                
                // Flush signals queued
                while (this.signalsQueued.length > 0) {
                    const signal = this.signalsQueued.shift();
                    this.sendSignal(signal);
                }
            });
            
            this.ws.on('close', () => {
                this.isConnected = false;
                console.log('📡 [SIGNAL_PROVIDER] Desconectado — retry em 5s...');
                setTimeout(() => this.connect(), this.reconnectInterval);
            });
            
            this.ws.on('error', (err) => {
                console.error(`📡 [SIGNAL_PROVIDER] Erro: ${err.message}`);
                this.isConnected = false;
            });
            
        } catch (err) {
            console.error(`📡 [SIGNAL_PROVIDER] Falha conexão: ${err.message}`);
        }
    }
    
    sendSignal(signalPacket) {
        if (!this.isConnected || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
            // Queue for later
            this.signalsQueued.push(signalPacket);
            if (this.signalsQueued.length > 100) {
                this.signalsQueued.shift(); // Evita overflow
            }
            return false;
        }
        
        try {
            this.ws.send(JSON.stringify(signalPacket));
            this.totalSignalsSent++;
            return true;
        } catch (err) {
            console.error(`📡 [SIGNAL_PROVIDER] Erro envio: ${err.message}`);
            this.signalsQueued.push(signalPacket);
            return false;
        }
    }
    
    getStatus() {
        return {
            connected: this.isConnected,
            url: this.signalServerUrl,
            signalsQueued: this.signalsQueued.length,
            totalSignalsSent: this.totalSignalsSent
        };
    }
}

// Singleton
const signalProvider = new SignalProviderClient();

/**
 * 🛡️ GXEON_SOVEREIGN_HOTFIX_v2.1 - Provider Factory
 * Cria providers com error handling preemptivo e failover
 */
class ProviderFactory {
    constructor() {
        this.providers = [
            process.env.ALCHEMY_WSS_URL_PRIMARY,
            process.env.ALCHEMY_WSS_URL_BACKUP,
            process.env.ALCHEMY_API_KEY ? `wss://arb-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}` : null,
            'wss://arb1.arbitrum.io/ws' // Public fallback
        ].filter(Boolean);
        this.currentIndex = 0;
        this.retryCount = 0;
        this.maxRetries = 10;
        this.cooldownMs = 10000; // 10s entre tentativas
    }

    /**
     * Cria provider com error handling robusto
     */
    async createProvider() {
        const url = this.providers[this.currentIndex];
        if (!url) {
            throw new Error('No WebSocket providers available');
        }

        return new Promise((resolve, reject) => {
            try {
                const ws = new WebSocket(url, {
                    headers: { 'User-Agent': 'GXEON-Sovereign/2.1' }
                });

                let resolved = false;

                // Timeout de conexão
                const timeout = setTimeout(() => {
                    if (!resolved) {
                        ws.terminate();
                        reject(new Error('WebSocket connection timeout'));
                    }
                }, 30000);

                // 🛡️ Handler de erro 429 - NUNCA crasha
                ws.on('error', (err) => {
                    const msg = err?.message || '';
                    if (msg.includes('429') || msg.includes('Unexpected server response')) {
                        console.warn(`[GXEON_GUARDIAN] Rate limit on provider ${this.currentIndex + 1}/${this.providers.length}`);
                        ws.terminate();
                        
                        // Switch para próximo provider
                        this.currentIndex = (this.currentIndex + 1) % this.providers.length;
                        this.retryCount++;
                        
                        if (this.retryCount < this.maxRetries) {
                            console.log(`[GXEON_GUARDIAN] Switching to provider ${this.currentIndex + 1} in ${this.cooldownMs}ms...`);
                            setTimeout(() => {
                                this.createProvider().then(resolve).catch(reject);
                            }, this.cooldownMs);
                        } else {
                            console.error('[GXEON_GUARDIAN] Max retries reached - operating in DEGRADED mode');
                            reject(new Error('All providers exhausted'));
                        }
                        return;
                    }
                    
                    // Outros erros - loga mas continua
                    console.error('[GXEON_GUARDIAN] WebSocket error:', msg);
                });

                ws.on('unexpected-response', (req, res) => {
                    if (res.statusCode === 429) {
                        console.warn('[GXEON_GUARDIAN] 429 on handshake');
                        ws.terminate();
                        this.currentIndex = (this.currentIndex + 1) % this.providers.length;
                        setTimeout(() => {
                            this.createProvider().then(resolve).catch(reject);
                        }, this.cooldownMs);
                    }
                });

                ws.on('open', () => {
                    if (!resolved) {
                        resolved = true;
                        clearTimeout(timeout);
                        this.retryCount = 0; // Reset contador em sucesso
                        console.log(`[GXEON_GUARDIAN] ✅ Provider ${this.currentIndex + 1}/${this.providers.length} connected`);
                        
                        // Cria provider ethers.js a partir do WebSocket estabelecido
                        try {
                            const provider = new ethers.WebSocketProvider(ws);
                            resolve(provider);
                        } catch (e) {
                            reject(e);
                        }
                    }
                });

                ws.on('close', (code) => {
                    if (!resolved) {
                        resolved = true;
                        clearTimeout(timeout);
                        reject(new Error(`WebSocket closed: ${code}`));
                    }
                });

            } catch (e) {
                reject(e);
            }
        });
    }
}

// Singleton factory
const providerFactory = new ProviderFactory();

/**
 * 🦄 DexLiquidityFetcher — Monitoramento de Pools DEX na Arbitrum
 * Substitui o RealTwitterFetcher (erro 402)
 * Usa DexScreener API (gratuita) para detectar novos pares
 */
class DexLiquidityFetcher {
    constructor() {
        this.baseUrl = 'https://api.dexscreener.com/latest';
        this.chainId = 'arbitrum';
        this.minLiquidityThreshold = 1000; // $1k USD — SENSITIVITY MAXIMUM
        this.knownPools = new Set(); // Cache de pools já detectados
        this.lastScanTime = 0;
        this.minScanInterval = 5000; // 5s entre scans (GXEON_SOVEREIGN v2.1)
        this.batchSize = 5; // Processa 5 pools por vez
        this.requestDelay = 200; // 200ms entre requisições
    }

    /**
     * Busca novos pares na Arbitrum com liquidez > $10k
     */
    async scanNewPools() {
        // Rate limiting protection
        const now = Date.now();
        if (now - this.lastScanTime < this.minScanInterval) {
            return []; // Skip scan if too soon
        }
        this.lastScanTime = now;

        try {
            // DexScreener API v1 — search endpoint for Arbitrum pairs
            // 🛡️ GXEON_SOVEREIGN v2.1: Rate limiting com delay entre requisições
            const response = await axios.get(
                `https://api.dexscreener.com/latest/dex/search?q=arbitrum`,
                { timeout: 10000 }
            );

            const pairs = response.data?.pairs || [];
            const newPools = [];
            let processedCount = 0;

            for (const pair of pairs) {
                // Filtro: apenas Arbitrum, liquidez > $10k, não visto antes
                if (pair.chainId !== 'arbitrum') continue;
                if (parseFloat(pair.liquidity?.usd || 0) < this.minLiquidityThreshold) continue;
                if (this.knownPools.has(pair.pairAddress)) continue;

                // 🛡️ GXEON_SOVEREIGN v2.1: Delay de 200ms entre processamentos
                processedCount++;
                if (processedCount > this.batchSize) {
                    await new Promise(resolve => setTimeout(resolve, this.requestDelay));
                    processedCount = 0;
                }

                // Marca como conhecido
                this.knownPools.add(pair.pairAddress);

                // Calcula métricas avançadas
                const poolData = this.analyzePool(pair);
                newPools.push(poolData);
            }

            console.log(`[DexLiquidityFetcher] Found ${newPools.length} new high-liquidity pools (${pairs.length} scanned)`);
            return newPools;

        } catch (error) {
            console.error('[DexLiquidityFetcher] Error:', error.message);
            return [];
        }
    }

    /**
     * Analisa um pool e calcula métricas de qualidade
     */
    analyzePool(pair) {
        const liquidityUsd = parseFloat(pair.liquidity?.usd || 0);
        const volume24h = parseFloat(pair.volume?.h24 || 0);
        const priceChange24h = parseFloat(pair.priceChange?.h24 || 0);

        // Calcula price impact estimado (simplificado)
        const priceImpact1k = this.estimatePriceImpact(liquidityUsd, 1000);
        const priceImpact10k = this.estimatePriceImpact(liquidityUsd, 10000);

        // Score de liquidez (0-1 baseado em profundidade)
        const liquidityDepth = this.calculateLiquidityDepth(liquidityUsd, volume24h);

        return {
            pairAddress: pair.pairAddress,
            chainId: 42161, // Arbitrum
            dexName: pair.dexId,
            token0: {
                address: pair.baseToken?.address,
                symbol: pair.baseToken?.symbol
            },
            token1: {
                address: pair.quoteToken?.address,
                symbol: pair.quoteToken?.symbol
            },
            liquidityUsd,
            volume24h,
            priceChange24h,
            priceImpact1k,
            priceImpact10k,
            liquidityDepth,
            detectedAt: new Date().toISOString(),
            priceUsd: pair.priceUsd,
            fdv: pair.fdv
        };
    }

    /**
     * Estima impacto de preço para um trade de tamanho específico
     */
    estimatePriceImpact(liquidityUsd, tradeSize) {
        if (liquidityUsd <= 0) return 1.0;
        // Fórmula simplificada: impacto ~ tradeSize / (2 * liquidity)
        const impact = tradeSize / (2 * liquidityUsd);
        return Math.min(impact, 1.0); // Max 100%
    }

    /**
     * Calcula profundidade da liquidez (0-1)
     */
    calculateLiquidityDepth(liquidityUsd, volume24h) {
        let score = 0;
        
        // Baseado em liquidez absoluta
        if (liquidityUsd > 1000000) score += 0.4; // > $1M
        else if (liquidityUsd > 100000) score += 0.3; // > $100k
        else if (liquidityUsd > 50000) score += 0.2; // > $50k
        else if (liquidityUsd > 10000) score += 0.1; // > $10k

        // Volume indica liquidez ativa
        const volumeRatio = volume24h / liquidityUsd;
        if (volumeRatio > 1.0) score += 0.3; // Volume > liquidez (muito ativo)
        else if (volumeRatio > 0.5) score += 0.2;
        else if (volumeRatio > 0.1) score += 0.1;

        return Math.min(score, 1.0);
    }

    /**
     * Limpa cache antigo (chamar periodicamente)
     */
    clearCache() {
        // Mantém apenas os últimos 5000 pools no cache
        if (this.knownPools.size > 5000) {
            const toKeep = Array.from(this.knownPools).slice(-4000);
            this.knownPools = new Set(toKeep);
        }
    }
}

/**
 * 🐋 SmartMoneyMonitor — Alchemy WebSocket para movimentações > 5 ETH
 * 🛡️ GXEON_SHIELD v21.2: Rate Limit Protection
 */
class SmartMoneyMonitor {
    constructor() {
        this.provider = null;
        this.ws = null;
        this.alchemyKey = process.env.ALCHEMY_API_KEY;
        this.wsUrl = this.alchemyKey 
            ? `wss://arb-mainnet.g.alchemy.com/v2/${this.alchemyKey}`
            : null;
        this.isConnected = false;
        this.transferCallbacks = [];
        this.minValueThreshold = 5; // 5 ETH
        this.stats = {
            totalTransfers: 0,
            largeTransfers: 0
        };
        // 🛡️ GXEON_SHIELD Config
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.baseDelay = 2000; // 2s inicial
        this.maxDelay = 120000; // 2min max
        this.reconnectTimer = null;
        this.isShuttingDown = false;
        this.lastStableConnection = 0;
        this.connectionStableTime = 300000; // 5min para reset
    }

    /**
     * Calcula delay com exponential backoff + jitter
     */
    getReconnectDelay() {
        // Delay exponencial: 2s, 4s, 8s, 16s... até 2min
        const delay = Math.min(
            this.baseDelay * Math.pow(2, this.reconnectAttempts),
            this.maxDelay
        );
        // Jitter aleatório 0-2s para evitar thundering herd
        const jitter = Math.random() * 2000;
        return delay + jitter;
    }

    /**
     * 🛡️ Cria WebSocket com handlers de erro PREVENTIVOS
     */
    createWebSocketWithProtection() {
        const WebSocket = require('ws');
        
        // Cria WebSocket raw primeiro
        const ws = new WebSocket(this.wsUrl, {
            headers: {
                'User-Agent': 'GXEON-SmartMoneyMonitor/21.2'
            }
        });

        // 🚨 HANDLERS DE ERRO IMEDIATOS (antes de qualquer operação)
        ws.on('error', (err) => {
            const errorMsg = err?.message || err?.toString() || 'Unknown WebSocket error';
            
            if (errorMsg.includes('429') || errorMsg.includes('Unexpected server response')) {
                console.warn('[GXEON_GUARDIAN] [SmartMoneyMonitor] Rate limited (429) - backing off');
                // Destrói socket imediatamente
                try { ws.terminate(); } catch(e) {}
                // Disconecta com backoff forçado
                this.handleDisconnection(true);
            } else {
                console.error('[GXEON_GUARDIAN] [SmartMoneyMonitor] WebSocket error:', errorMsg);
            }
        });

        ws.on('unexpected-response', (request, response) => {
            if (response.statusCode === 429) {
                console.warn('[GXEON_GUARDIAN] [SmartMoneyMonitor] 429 on handshake - rate limited');
                try { ws.terminate(); } catch(e) {}
                this.handleDisconnection(true);
            }
        });

        ws.on('close', (code, reason) => {
            console.warn(`[GXEON_GUARDIAN] [SmartMoneyMonitor] WebSocket closed (${code})`);
            this.handleDisconnection();
        });

        // Retorna WebSocket protegido
        return ws;
    }

    /**
     * Inicia monitoramento WebSocket com proteção total
     */
    async start() {
        if (this.isShuttingDown) return false;

        // Limpa timer anterior
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }

        try {
            console.log(`[SmartMoneyMonitor] Connecting via ProviderFactory... (attempt ${this.reconnectAttempts + 1})`);
            
            // 🛡️ Usa ProviderFactory com failover automático
            this.provider = await providerFactory.createProvider();

            // Escuta novos blocos
            this.provider.on('block', async (blockNumber) => {
                try {
                    await this.analyzeBlock(blockNumber);
                } catch (err) {
                    // Silencioso
                }
            });

            // Marca como estável
            this.isConnected = true;
            this.reconnectAttempts = 0;
            this.lastStableConnection = Date.now();
            
            console.log('[SmartMoneyMonitor] ✅ WebSocket connected to Arbitrum');
            return true;

        } catch (error) {
            const errorMsg = error?.message || error?.toString() || 'Connection failed';
            console.error('[GXEON_GUARDIAN] [SmartMoneyMonitor] Connection failed:', errorMsg);
            
            // Cleanup em caso de falha
            if (this.provider) {
                try { this.provider.destroy(); } catch(e) {}
                this.provider = null;
            }
            
            this.handleDisconnection(true);
            return false;
        }
    }

    /**
     * Trata desconexão com exponential backoff
     */
    handleDisconnection(forceBackoff = false) {
        if (this.isShuttingDown) return;
        
        this.isConnected = false;

        // Incrementa tentativas
        this.reconnectAttempts++;

        if (this.reconnectAttempts > this.maxReconnectAttempts) {
            console.error('[GXEON_GUARDIAN] [SmartMoneyMonitor] Max reconnection attempts reached');
            console.log('[GXEON_GUARDIAN] [SmartMoneyMonitor] Switching to DEGRADED mode (REST API only)');
            // Continua operando sem WebSocket
            return;
        }

        const delay = this.getReconnectDelay();
        console.log(`[GXEON_GUARDIAN] [SmartMoneyMonitor] Reconnecting in ${(delay/1000).toFixed(1)}s (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        
        this.reconnectTimer = setTimeout(() => this.start(), delay);
    }

    /**
     * Limpa recursos
     */
    cleanup() {
        if (this.ws) {
            try {
                this.ws.removeAllListeners();
                this.ws.terminate();
            } catch (e) {
                // Ignore
            }
            this.ws = null;
        }
        if (this.provider) {
            try {
                this.provider.removeAllListeners();
                this.provider.destroy();
            } catch (e) {
                // Ignore
            }
            this.provider = null;
        }
        this.isConnected = false;
    }

    /**
     * Processa um bloco em busca de grandes transfers
     */
    async processBlock(blockNumber) {
        if (!this.provider) return;

        try {
            // Busca transfers de ETH nativo com valor > 5 ETH
            const block = await this.provider.getBlock(blockNumber, true);
            if (!block || !block.transactions) return;

            const largeTransfers = [];

            for (const tx of block.transactions) {
                const valueEth = parseFloat(ethers.formatEther(tx.value || 0));
                
                if (valueEth >= this.minEthThreshold) {
                    const transfer = {
                        chainId: 42161,
                        from: tx.from,
                        to: tx.to,
                        amount: valueEth,
                        amountUsd: await this.estimateUsdValue(valueEth),
                        tokenSymbol: 'ETH',
                        blockNumber,
                        txHash: tx.hash,
                        flowType: this.classifyTransfer(tx),
                        detectedAt: new Date().toISOString()
                    };

                    largeTransfers.push(transfer);
                    
                    // Notifica callbacks
                    this.transferCallbacks.forEach(cb => cb(transfer));
                }
            }

            if (largeTransfers.length > 0) {
                console.log(`[SmartMoneyMonitor] Block ${blockNumber}: ${largeTransfers.length} large transfers detected`);
            }

            return largeTransfers;

        } catch (error) {
            console.error(`[SmartMoneyMonitor] Block ${blockNumber} processing failed:`, error.message);
            return [];
        }
    }

    /**
     * Estima valor em USD baseado em ETH
     */
    async estimateUsdValue(ethAmount) {
        // Cache local ou valor fixo estimado para não sobrecarregar APIs
        const ethPriceUsd = 3500; // Atualizar conforme mercado ou cache externo
        return ethAmount * ethPriceUsd;
    }

    /**
     * Classifica o tipo de transferência
     */
    classifyTransfer(tx) {
        // Heurísticas simples para classificação
        if (!tx.to) return 'contract_creation';
        
        // Detectar se é contrato conhecido (DEX, Bridge, etc)
        const toLower = tx.to.toLowerCase();
        
        // Endereços comuns de DEX/Bridges na Arbitrum (exemplos)
        const knownContracts = {
            '0xe592427a0aece92de3edee1f18e0157c05861564': 'uniswap_v3',
            '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45': 'uniswap_router',
            '0x0000000000000000000000000000000000000000': 'burn'
        };

        if (knownContracts[toLower]) {
            return knownContracts[toLower];
        }

        // Se valor é muito alto (> 50 ETH), classifica como whale
        const valueEth = parseFloat(ethers.formatEther(tx.value || 0));
        if (valueEth > 50) return 'whale_movement';

        return 'regular_transfer';
    }

    /**
     * Registra callback para novos transfers
     */
    onLargeTransfer(callback) {
        this.transferCallbacks.push(callback);
    }

    /**
     * Para o monitor
     */
    stop() {
        if (this.provider) {
            this.provider.removeAllListeners('block');
            this.provider.destroy();
            this.provider = null;
        }
        this.isConnected = false;
        console.log('[SmartMoneyMonitor] Stopped');
    }
}

/**
 * 🔫 MempoolSniper — Detecção de liquidez em pending transactions
 * 🛡️ GXEON_SHIELD v21.2: Rate Limit Protection
 */
class MempoolSniper {
    constructor() {
        this.provider = null;
        this.ws = null;
        this.alchemyKey = process.env.ALCHEMY_API_KEY;
        this.wsUrl = this.alchemyKey 
            ? `wss://arb-mainnet.g.alchemy.com/v2/${this.alchemyKey}`
            : null;
        this.isConnected = false;
        this.pendingTxCallbacks = [];
        this.stats = {
            totalPendingSeen: 0,
            largeLiquidityDetected: 0
        };
        // 🛡️ GXEON_SHIELD Config
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.baseDelay = 2000; // 2s inicial
        this.maxDelay = 120000; // 2min max
        this.reconnectTimer = null;
        this.isShuttingDown = false;
        this.lastStableConnection = 0;
        this.connectionStableTime = 300000; // 5min para reset
    }

    /**
     * Calcula delay com exponential backoff + jitter
     */
    getReconnectDelay() {
        const delay = Math.min(
            this.baseDelay * Math.pow(2, this.reconnectAttempts),
            this.maxDelay
        );
        const jitter = Math.random() * 2000;
        return delay + jitter;
    }

    /**
     * 🛡️ Cria WebSocket com handlers de erro PREVENTIVOS
     */
    createWebSocketWithProtection() {
        const WebSocket = require('ws');
        
        const ws = new WebSocket(this.wsUrl, {
            headers: {
                'User-Agent': 'GXEON-MempoolSniper/21.2'
            }
        });

        // 🚨 HANDLERS DE ERRO IMEDIATOS
        ws.on('error', (err) => {
            const errorMsg = err?.message || err?.toString() || 'Unknown WebSocket error';
            
            if (errorMsg.includes('429') || errorMsg.includes('Unexpected server response')) {
                console.warn('[GXEON_GUARDIAN] [MempoolSniper] Rate limited (429) - backing off');
                try { ws.terminate(); } catch(e) {}
                this.handleDisconnection(true);
            } else {
                console.error('[GXEON_GUARDIAN] [MempoolSniper] WebSocket error:', errorMsg);
            }
        });

        ws.on('unexpected-response', (request, response) => {
            if (response.statusCode === 429) {
                console.warn('[GXEON_GUARDIAN] [MempoolSniper] 429 on handshake - rate limited');
                try { ws.terminate(); } catch(e) {}
                this.handleDisconnection(true);
            }
        });

        ws.on('close', (code, reason) => {
            console.warn(`[GXEON_GUARDIAN] [MempoolSniper] WebSocket closed (${code})`);
            this.handleDisconnection();
        });

        return ws;
    }

    /**
     * Inicia escuta do mempool com proteção total
     */
    async start() {
        if (this.isShuttingDown) return false;

        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }

        try {
            console.log(`[MempoolSniper] Connecting via ProviderFactory... (attempt ${this.reconnectAttempts + 1})`);
            
            // 🛡️ Usa ProviderFactory com failover automático
            this.provider = await providerFactory.createProvider();

            // Escuta pending transactions
            this.provider.on('pending', async (txHash) => {
                try {
                    await this.processPendingTransaction(txHash);
                } catch (err) {
                    // Silencioso
                }
            });

            this.isConnected = true;
            this.reconnectAttempts = 0;
            this.lastStableConnection = Date.now();
            
            console.log(`[MempoolSniper] 🔫 Mempool sniper activated`);
            return true;

        } catch (error) {
            const errorMsg = error?.message || error?.toString() || 'Connection failed';
            console.error('[GXEON_GUARDIAN] [MempoolSniper] Connection failed:', errorMsg);
            
            if (this.provider) {
                try { this.provider.destroy(); } catch(e) {}
                this.provider = null;
            }
            
            this.handleDisconnection(true);
            return false;
        }
    }

    /**
     * Trata desconexão com exponential backoff
     */
    handleDisconnection(forceBackoff = false) {
        if (this.isShuttingDown) return;
        
        this.isConnected = false;
        this.cleanup();

        this.reconnectAttempts++;

        if (this.reconnectAttempts > this.maxReconnectAttempts) {
            console.error('[GXEON_GUARDIAN] [MempoolSniper] Max reconnection attempts reached');
            console.log('[GXEON_GUARDIAN] [MempoolSniper] Switching to DEGRADED mode');
            return;
        }

        const delay = this.getReconnectDelay();
        console.log(`[GXEON_GUARDIAN] [MempoolSniper] Reconnecting in ${(delay/1000).toFixed(1)}s (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        
        this.reconnectTimer = setTimeout(() => this.start(), delay);
    }

    /**
     * Limpa recursos
     */
    cleanup() {
        if (this.ws) {
            try {
                this.ws.removeAllListeners();
                this.ws.terminate();
            } catch (e) {}
            this.ws = null;
        }
        if (this.provider) {
            try {
                this.provider.removeAllListeners();
                this.provider.destroy();
            } catch (e) {}
            this.provider = null;
        }
        this.isConnected = false;
    }

    /**
     * Processa transação pendente
     */
    async processPendingTransaction(txHash) {
        try {
            const tx = await this.provider.getTransaction(txHash);
            if (!tx) return;

            this.stats.totalPendingSeen++;

            // Verifica se é transação de alto valor (> 2 ETH no mempool)
            const valueEth = parseFloat(ethers.formatEther(tx.value || 0));
            if (valueEth >= 2) {
                const pendingData = {
                    txHash: tx.hash,
                    from: tx.from,
                    to: tx.to,
                    valueEth,
                    valueUsd: valueEth * 3500, // Estimativa
                    gasPrice: tx.gasPrice ? ethers.formatUnits(tx.gasPrice, 'gwei') : null,
                    detectedAt: new Date().toISOString(),
                    isHighValue: valueEth >= 5,
                    type: this.classifyPendingTx(tx)
                };

                if (valueEth >= 5) {
                    this.stats.largeLiquidityDetected++;
                    console.log(`[MempoolSniper] 🎯 LARGE PENDING: ${valueEth.toFixed(2)} ETH from ${tx.from?.slice(0, 8)}...`);
                }

                // Notifica callbacks
                this.pendingTxCallbacks.forEach(cb => cb(pendingData));
            }

        } catch (error) {
            // Ignora erros de transações não encontradas
        }
    }

    /**
     * Classifica tipo de transação pendente
     */
    classifyPendingTx(tx) {
        if (!tx.to) return 'contract_deployment';
        
        const toLower = tx.to.toLowerCase();
        const valueEth = parseFloat(ethers.formatEther(tx.value || 0));
        
        // Heurísticas para detectar adição de liquidez
        if (valueEth >= 5) {
            return 'potential_liquidity_add';
        }
        
        return 'high_value_transfer';
    }

    onPendingLiquidity(callback) {
        this.pendingTxCallbacks.push(callback);
    }

    getStats() {
        return { ...this.stats };
    }

    stop() {
        if (this.provider) {
            this.provider.removeAllListeners('pending');
            this.provider.destroy();
            this.provider = null;
        }
        this.isConnected = false;
        console.log('[MempoolSniper] Stopped');
    }
}

/**
 * 🎯 RADAR SHIX v2.0 — Liquidity-First DEX Monitoring
 * 
 * Abandona Twitter API (erro 402) em favor de:
 * - DexScreener API para novos pools
 * - Alchemy WebSocket para smart money
 * - Scan a cada 1s (sync com blocos Arbitrum)
 */
class RadarShixService {
    constructor() {
        this.dexFetcher = new DexLiquidityFetcher();
        this.smartMoney = new SmartMoneyMonitor();
        this.mempoolSniper = new MempoolSniper();
        this.isRunning = false;
        this.intervalId = null;
        this.scanInterval = 15000; // 15 segundos — respeita rate limit DexScreener
        this.blockCount = 0;
        this.opportunitiesFound = 0;
        this.startTime = null;
        this.heartbeatInterval = null;
        
        // 🎯 Visual telemetry for Railway Dashboard
        this.telemetry = {
            scansPerSecond: 0,
            lastScansCount: 0,
            pendingTxSeen: 0,
            smartMoneyEvents: 0,
            highLiquidityAlerts: 0,
            mevSignalsEmitted: 0
        };
    }

    /**
     * Inicia o radar de liquidez
     */
    async start() {
        if (this.isRunning) {
            console.log('[RADAR_SHIX] Already running');
            return;
        }

        this.isRunning = true;
        this.startTime = Date.now();
        
        const isLiveMode = process.env.MEV_LIVE_MODE === 'true';
        const signalMode = process.env.SIGNAL_MODE || 'broadcast';
        
        console.log('╔═══════════════════════════════════════════════════════════════╗');
        console.log('║  🎯 RADAR SHIX v3.0 — LIGHTHOUSE SIGNAL PROVIDER               ║');
        console.log('╠═══════════════════════════════════════════════════════════════╣');
        console.log('║  Architecture: M2M Alpha Broadcast — Zero Gas                   ║');
        console.log('║  Source: DexScreener API (FREE) + Alchemy WebSocket            ║');
        console.log('║  Chain: Arbitrum Mainnet (~1s/block)                           ║');
        console.log('║  Alert: New pools > $10k USD | Smart money > 5 ETH             ║');
        console.log('║  Mempool: 🔫 Sniper active for pending liquidity               ║');
        console.log(`║  Signal Mode: 📡 ${signalMode.toUpperCase().padEnd(15)} (WebSocket Stream)          ║`);
        console.log(`║  Server: ${(process.env.SIGNAL_SERVER_URL || 'ws://localhost:8765/ws/radar').slice(0, 40)}...     ║`);
        console.log('╚═══════════════════════════════════════════════════════════════╝');
        
        // Conecta ao Signal Server (M2M Alpha Broadcast)
        if (signalMode === 'broadcast') {
            signalProvider.connect();
            console.log('📡 [RADAR_SHIX] Signal Provider WebSocket conectando...');
        }

        // Inicia monitor de smart money (com graceful fail)
        let smartMoneySuccess = false;
        try {
            smartMoneySuccess = await this.smartMoney.start();
        } catch (err) {
            console.error('[RADAR_SHIX] SmartMoneyMonitor failed to start:', err.message);
            // Continua mesmo se falhar
        }
        
        // 🛡️ GXEON_SHIELD: Delay de 10s entre conexões para evitar rate limit 429
        if (smartMoneySuccess) {
            console.log('[GXEON_SHIELD] ⏱️ Aguardando 10s antes de iniciar MempoolSniper...');
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
        
        // Inicia mempool sniper para pending transactions (com graceful fail)
        try {
            await this.mempoolSniper.start();
        } catch (err) {
            console.error('[RADAR_SHIX] MempoolSniper failed to start:', err.message);
            // Continua mesmo se falhar
        }
        
        // Registra callback para transfers grandes
        if (this.smartMoney) {
            this.smartMoney.onLargeTransfer(async (transfer) => {
                this.telemetry.smartMoneyEvents++;
                await this.logSmartMoneyTransfer(transfer);
            });
        }
        
        // Registra callback para pending transactions
        if (this.mempoolSniper) {
            this.mempoolSniper.onPendingLiquidity(async (pending) => {
                this.telemetry.pendingTxSeen++;
                if (pending.isHighValue) {
                    await this.logPendingLiquidity(pending);
                }
            });
        }

        // Primeiro scan imediato
        await this.executeScan();

        // Scan perpétuo a cada 1s
        this.intervalId = setInterval(() => {
            this.executeScan();
        }, this.scanInterval);

        // Heartbeat para Railway Dashboard
        this.startHeartbeat();
    }

    /**
     * Para o radar
     */
    stop() {
        this.isRunning = false;
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
        }
        this.smartMoney.stop();
        this.mempoolSniper.stop();
        console.log('[RADAR_SHIX] Stopped');
    }

    /**
     * Ciclo de scan: DexScreener + Telemetria
     */
    async executeScan() {
        const scanStart = Date.now();
        this.blockCount++;

        try {
            // 1. Busca novos pools no DexScreener
            const newPools = await this.dexFetcher.scanNewPools();
            
            let highLiquidityAlerts = 0;

            // 2. Processa cada novo pool
            for (const pool of newPools) {
                await this.processNewPool(pool);
                
                if (pool.liquidityUsd >= 10000) {
                    highLiquidityAlerts++;
                }
            }

            if (newPools.length > 0) {
                this.opportunitiesFound += newPools.length;
                this.telemetry.highLiquidityAlerts += highLiquidityAlerts;
                console.log(`[RADAR_SCAN] 🎯 ${newPools.length} NEW POOLS | 🚨 ${highLiquidityAlerts} HIGH LIQUIDITY`);
            }

            // 3. Log de telemetria
            await this.logScanTelemetry({
                blockNumber: this.blockCount,
                newPools: newPools.length,
                highLiquidityAlerts,
                durationMs: Date.now() - scanStart
            });

            // 4. Limpa cache periodicamente
            if (this.blockCount % 1000 === 0) {
                this.dexFetcher.clearCache();
            }

        } catch (error) {
            console.error('[RADAR_SCAN] Error:', error.message);
            await this.logScanTelemetry({
                blockNumber: this.blockCount,
                newPools: 0,
                highLiquidityAlerts: 0,
                durationMs: Date.now() - scanStart,
                error: error.message
            });
        }
    }

    /**
     * Emite oportunidade para MEV-Nexus (Signal Provider Mode)
     * Matrix V3: Lighthouse Signal Provider — Zero Gas Architecture
     */
    emitMevOpportunity(pool) {
        // 🚨 SENSITIVITY MAXIMUM: Threshold mínimo de $500 para disparar sinal
        const minLiquidity = process.env.SIGNAL_MIN_LIQUIDITY || 500;
        if (pool.liquidityUsd < minLiquidity) return;

        const signalId = `sig-${pool.pairAddress.slice(2, 10)}-${Date.now().toString(36)}`;
        const estimatedProfit = this.estimateMevProfit(pool);
        
        // Signal Packet estruturado (M2M Alpha Broadcast)
        const signalPacket = {
            signal_id: signalId,
            timestamp: new Date().toISOString(),
            source: 'RADAR_SHIX',
            
            opportunity_type: 'NEW_HIGH_LIQUIDITY_POOL',
            chain: pool.chainId === 42161 ? 'arbitrum' : 'unknown',
            dex: pool.dexName || 'unknown',
            pool_address: pool.pairAddress,
            token_a: {
                address: pool.token0.address,
                symbol: pool.token0.symbol
            },
            token_b: {
                address: pool.token1.address,
                symbol: pool.token1.symbol
            },
            
            // Métricas financeiras
            liquidity_usd: pool.liquidityUsd,
            volume_24h: pool.volume24h,
            estimated_profit_usd: estimatedProfit,
            confidence_score: this.calculateConfidence(pool),
            
            // Técnico
            block_number: this.blockCount,
            gas_estimate: 150000,
            
            // 🚨 SENSITIVITY MAXIMUM: Prioridade ajustada para lucros de $0.10+
            priority: estimatedProfit > 1 ? 'critical' : estimatedProfit > 0.5 ? 'high' : estimatedProfit > 0.10 ? 'normal' : 'low',
            ttl_seconds: 300,
            
            // Metadados para billing
            beneficiary: '0x3955d559055DadB7067054cB6E6f974710345224',
            
            // Legacy format (para compatibilidade)
            event: 'OPPORTUNITY_DETECTED',
            id: signalId,
            type: 'NEW_HIGH_LIQUIDITY_POOL',
            poolAddress: pool.pairAddress,
            dexName: pool.dexName,
            liquidityUsd: pool.liquidityUsd,
            profitUsd: estimatedProfit,
            contractAddress: pool.pairAddress
        };

        // Broadcast via WebSocket para Signal Server
        const sent = signalProvider.sendSignal(signalPacket);
        
        // Output JSON para pipe (backward compatibility)
        console.log(JSON.stringify(signalPacket));
        
        // Telemetry
        this.telemetry.mevSignalsEmitted = (this.telemetry.mevSignalsEmitted || 0) + 1;
        
        // 🚨 SENSITIVITY MAXIMUM: Log em QUALQUER sinal > $0.10
        if (estimatedProfit > 0.10) {
            const emoji = estimatedProfit > 1 ? '🚨' : estimatedProfit > 0.5 ? '🔥' : '💰';
            console.log(`${emoji} [RADAR_SHIX] SIGNAL EMITTED: ${signalId} | $${estimatedProfit.toFixed(2)} profit | ` +
                `Pool: ${pool.pairAddress.slice(0, 12)}... | Broadcast: ${sent ? 'OK' : 'QUEUED'}`);
        }
    }
    
    /**
     * Calcula score de confiança para o sinal
     */
    calculateConfidence(pool) {
        let score = 0.5; // Base
        
        // Liquidez alta = mais confiança
        if (pool.liquidityUsd > 100000) score += 0.2;
        if (pool.liquidityUsd > 500000) score += 0.15;
        
        // Volume significativo
        if (pool.volume24h > pool.liquidityUsd * 0.1) score += 0.1;
        
        // Profundidade de liquidez
        if (pool.liquidityDepth && pool.liquidityDepth > 0.7) score += 0.05;
        
        return Math.min(score, 1.0);
    }

    /**
     * Estima lucro potencial para MEV
     */
    estimateMevProfit(pool) {
        // Heurística: pools com alta liquidez e volume têm maior potencial
        const liquidityScore = Math.min(pool.liquidityUsd / 100000, 10); // 0-10
        const volumeScore = Math.min(pool.volume24h / pool.liquidityUsd, 2); // 0-2
        const depthScore = pool.liquidityDepth || 0.5;
        
        // Lucro estimado baseado em scores
        const estimatedProfit = (liquidityScore * volumeScore * depthScore * 0.5).toFixed(2);
        return parseFloat(estimatedProfit);
    }

    /**
     * Processa um novo pool detectado
     */
    async processNewPool(pool) {
        // Emite sinal para MEV-Nexus (pipe) — ANTES do Supabase para menor latência
        this.emitMevOpportunity(pool);
        
        if (!supabase) return;
        try {
            // Insere no Supabase
            const { data, error } = await supabase
                .from('radar_liquidity_pools')
                .insert({
                    chain_id: pool.chainId,
                    pair_address: pool.pairAddress,
                    token0_address: pool.token0.address,
                    token1_address: pool.token1.address,
                    token0_symbol: pool.token0.symbol,
                    token1_symbol: pool.token1.symbol,
                    dex_name: pool.dexName,
                    liquidity_usd: pool.liquidityUsd,
                    liquidity_depth: pool.liquidityDepth,
                    volume_24h_usd: pool.volume24h,
                    price_impact_1k: pool.priceImpact1k,
                    price_impact_10k: pool.priceImpact10k,
                    detected_at: pool.detectedAt,
                    status: pool.liquidityUsd >= 10000 ? 'high_alert' : 'new',
                    alert_triggered: pool.liquidityUsd >= 10000
                })
                .select()
                .single();

            if (error) {
                // Pool já existe (duplicate)
                if (error.code === '23505') return;
                throw error;
            }

            // Log de alerta se alta liquidez
            if (pool.liquidityUsd >= 10000) {
                console.log(`[POOL_ALERT] 🚨 High liquidity detected:`);
                console.log(`  DEX: ${pool.dexName}`);
                console.log(`  Pair: ${pool.token0.symbol}/${pool.token1.symbol}`);
                console.log(`  Liquidity: $${pool.liquidityUsd.toLocaleString()}`);
                console.log(`  Price Impact (10k): ${(pool.priceImpact10k * 100).toFixed(2)}%`);
            }

        } catch (error) {
            console.error('[processNewPool] Error:', error.message);
        }
    }

    /**
     * Log de transferência smart money
     */
    async logSmartMoneyTransfer(transfer) {
        if (!supabase) return;
        try {
            const isWhale = transfer.amountUsd >= 100000;
            const isNewWallet = false; // TODO: implementar verificação

            const { error } = await supabase
                .from('radar_smart_money_flows')
                .insert({
                    chain_id: transfer.chainId,
                    from_address: transfer.from,
                    to_address: transfer.to,
                    token_symbol: transfer.tokenSymbol,
                    amount: transfer.amount,
                    amount_usd: transfer.amountUsd,
                    flow_type: transfer.flowType,
                    block_number: transfer.blockNumber,
                    transaction_hash: transfer.txHash,
                    detected_at: transfer.detectedAt,
                    is_whale: isWhale,
                    is_new_wallet: isNewWallet,
                    smart_score: isWhale ? 0.9 : 0.5
                });

            if (error) throw error;

            if (isWhale) {
                console.log(`[SMART_MONEY] 🐋 WHALE ALERT: ${transfer.amount.toFixed(2)} ETH ($${transfer.amountUsd.toLocaleString()})`);
            }

        } catch (error) {
            console.error('[logSmartMoneyTransfer] Error:', error.message);
        }
    }

    /**
     * Log de liquidez pendente (mempool sniper)
     */
    async logPendingLiquidity(pending) {
        if (!supabase) return;
        try {
            // Log em tabela separada ou mesma de smart money com flag
            const { error } = await supabase
                .from('radar_smart_money_flows')
                .insert({
                    chain_id: 42161,
                    from_address: pending.from,
                    to_address: pending.to,
                    token_symbol: 'ETH',
                    amount: pending.valueEth,
                    amount_usd: pending.valueUsd,
                    flow_type: pending.type,
                    block_number: 0, // Pending = ainda sem bloco
                    transaction_hash: pending.txHash,
                    detected_at: pending.detectedAt,
                    is_whale: pending.valueUsd >= 100000,
                    is_new_wallet: false,
                    smart_score: 0.7, // Alto score por ser pre-confirmação
                    is_pending: true // Flag para identificar mempool
                });

            if (error) throw error;

            console.log(`[PENDING_LIQUIDITY] 🔫 Pre-confirmed: ${pending.valueEth.toFixed(2)} ETH → ${pending.to?.slice(0, 12)}...`);

        } catch (error) {
            console.error('[logPendingLiquidity] Error:', error.message);
        }
    }

    /**
     * Log de telemetria do scan
     */
    async logScanTelemetry({ blockNumber, newPools, highLiquidityAlerts, durationMs, error = null }) {
        if (!supabase) return;
        try {
            await supabase.from('radar_liquidity_telemetry').insert({
                block_number: blockNumber,
                new_pools_detected: newPools,
                high_liquidity_alerts: highLiquidityAlerts,
                total_pools_tracked: this.dexFetcher.knownPools.size,
                scan_duration_ms: durationMs,
                error: error,
                scanned_at: new Date().toISOString()
            });
        } catch (e) {
            // Silencioso
        }
    }

    /**
     * Heartbeat para Railway Dashboard — Visual Telemetry
     */
    startHeartbeat() {
        // Calcula scans por segundo a cada intervalo
        this.telemetry.lastScansCount = this.blockCount;
        
        this.heartbeatInterval = setInterval(async () => {
            const uptime = Math.floor((Date.now() - this.startTime) / 1000);
            const hours = Math.floor(uptime / 3600);
            const mins = Math.floor((uptime % 3600) / 60);
            
            // Calcula scans por segundo
            const scansSinceLast = this.blockCount - this.telemetry.lastScansCount;
            this.telemetry.scansPerSecond = (scansSinceLast / 30).toFixed(2); // 30s interval
            this.telemetry.lastScansCount = this.blockCount;
            
            // 🎯 Visual output for Railway Dashboard (inclui MEV signals)
            const mevSignals = this.telemetry.mevSignalsEmitted || 0;
            console.log(`[RADAR_HEARTBEAT] ⏱️ ${hours}h ${mins}m | ⚡ ${this.telemetry.scansPerSecond} scans/s | 🔍 ${this.blockCount} total | 🎯 ${this.opportunitiesFound} pools | 📊 ${this.dexFetcher.knownPools.size} tracked | 🔫 ${this.telemetry.pendingTxSeen} pending | 🐋 ${this.telemetry.smartMoneyEvents} smart | 🌑 ${mevSignals} MEV signals`);
            
            // Ping no Supabase com telemetry completa
            if (!supabase) return;
            try {
                await supabase.from('radar_liquidity_heartbeat').upsert({
                    id: 'liquidity_radar_v1',
                    last_ping: new Date().toISOString(),
                    uptime_seconds: uptime,
                    block_count: this.blockCount,
                    total_pools_detected: this.opportunitiesFound,
                    status: 'scanning',
                    scan_interval_ms: this.scanInterval,
                    total_smart_money_events: this.telemetry.smartMoneyEvents,
                    high_liquidity_alerts: this.telemetry.highLiquidityAlerts
                });
            } catch (e) {}
            
        }, 30000); // 30 segundos
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // API ENDPOINT SUPPORT METHODS (Billing-Protected)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Get opportunities (high liquidity pools)
     */
    async getOpportunities(limit = 20) {
        if (!supabase) return [];
        try {
            const { data } = await supabase
                .from('radar_liquidity_pools')
                .select('*')
                .eq('alert_triggered', true)
                .order('detected_at', { ascending: false })
                .limit(limit);

            return data || [];
        } catch (error) {
            console.error('[RADAR_SHIX] getOpportunities error:', error);
            return [];
        }
    }

    /**
     * Get last update timestamp
     */
    async getLastUpdateTime() {
        if (!supabase) return new Date().toISOString();
        try {
            const { data } = await supabase
                .from('radar_liquidity_heartbeat')
                .select('last_ping')
                .eq('id', 'liquidity_radar_v1')
                .single();

            return data?.last_ping || new Date().toISOString();
        } catch (error) {
            return new Date().toISOString();
        }
    }

    /**
     * Check if radar is active
     */
    isActive() {
        return this.isRunning;
    }

    /**
     * Get service uptime in seconds
     */
    getUptime() {
        return this.isRunning && this.startTime 
            ? Math.floor((Date.now() - this.startTime) / 1000) 
            : 0;
    }

    /**
     * Get total opportunities count
     */
    async getTotalOpportunities() {
        if (!supabase) return 0;
        try {
            const { count } = await supabase
                .from('radar_liquidity_pools')
                .select('*', { count: 'exact' });
            return count || 0;
        } catch (error) {
            return 0;
        }
    }

    /**
     * Get current status
     */
    getStatus() {
        return {
            isRunning: this.isRunning,
            blockCount: this.blockCount,
            opportunitiesFound: this.opportunitiesFound,
            uptimeSeconds: this.getUptime(),
            trackedPools: this.dexFetcher.knownPools.size,
            smartMoneyConnected: this.smartMoney.isConnected,
            scanIntervalMs: this.scanInterval
        };
    }

    /**
     * Trigger manual scan
     */
    async triggerScan() {
        console.log('[RADAR_SHIX] Manual scan triggered via API');
        await this.executeScan();
        return { 
            success: true, 
            message: 'Scan iniciado manualmente',
            status: this.getStatus()
        };
    }
}

// Export singleton
const radarShixService = new RadarShixService();

export { radarShixService, RadarShixService, DexLiquidityFetcher, SmartMoneyMonitor, MempoolSniper };
export default radarShixService;

// ═══════════════════════════════════════════════════════════════════════════
// CLI ENTRY POINT — Permite execução direta via node radarShix.js
// ═══════════════════════════════════════════════════════════════════════════
const command = process.argv[2];

if (command === 'start' || command === undefined) {
    radarShixService.start().catch(err => {
        console.error('[RADAR_SHIX] Failed to start:', err.message);
        process.exit(1);
    });
} else if (command === 'stop') {
    radarShixService.stop();
    process.exit(0);
} else if (command === 'status') {
    console.log(JSON.stringify(radarShixService.getStatus(), null, 2));
    process.exit(0);
}
