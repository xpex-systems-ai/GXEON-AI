"""
═══════════════════════════════════════════════════════════════════════════════
GXEON LIGHTHOUSE SIGNAL PROVIDER v3.0 — M2M Alpha Broadcast
═══════════════════════════════════════════════════════════════════════════════

Arquitetura: Zero-Gas Signal Station
Protocolo: M2M_ALPHA_BROADCAST
Entrega: FastAPI WebSocket Stream

O radar detecta, o farol transmite, os clientes consomem.
Monetização: Pay-per-signal / Subscription tier

Comandante: Júnior Sena
Beneficiário: 0x3955d559055DadB7067054cB6E6f974710345224
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import json
import time
import hashlib
from datetime import datetime, timezone
from typing import Dict, Set, Optional, List, Any
from dataclasses import dataclass, asdict
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

# ═══════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class SignalPacket:
    """Pacote de sinal MEV otimizado para transmissão de alta velocidade"""
    signal_id: str
    timestamp: str
    source: str
    
    # Dados da oportunidade
    opportunity_type: str  # 'NEW_POOL', 'SMART_MONEY', 'LIQUIDITY_SPIKE'
    chain: str
    dex: str
    pool_address: str
    token_a: str
    token_b: str
    
    # Métricas financeiras
    liquidity_usd: float
    volume_24h: float
    estimated_profit_usd: float
    confidence_score: float  # 0.0 - 1.0
    
    # Dados técnicos
    block_number: Optional[int] = None
    tx_hash: Optional[str] = None
    gas_estimate: Optional[int] = None
    
    # Metadados para consumidor
    priority: str = 'normal'  # 'low', 'normal', 'high', 'critical'
    ttl_seconds: int = 300  # Time-to-live
    
    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)
    
    def to_dict(self) -> dict:
        return asdict(self)

@dataclass
class ConsumerSession:
    """Sessão de consumidor M2M"""
    client_id: str
    api_key: str
    tier: str  # 'free', 'basic', 'premium', 'enterprise'
    connected_at: datetime
    signals_consumed: int = 0
    last_signal_at: Optional[datetime] = None
    filters: Dict[str, Any] = None

# ═══════════════════════════════════════════════════════════════════════════════
# SIGNAL BROADCAST ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class SignalBroadcastEngine:
    """Motor de broadcast de alta fidelidade — Zero Gas, Infinite Uptime"""
    
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.consumer_sessions: Dict[str, ConsumerSession] = {}
        self.signal_history: List[SignalPacket] = []
        self.metrics = {
            'total_signals_broadcast': 0,
            'total_consumers_connected': 0,
            'signals_by_tier': {'free': 0, 'basic': 0, 'premium': 0, 'enterprise': 0},
            'potential_profit_broadcast': 0.0,
            'start_time': datetime.now(timezone.utc)
        }
        self.rate_limits = {
            'free': 10,      # 10 sinais/min
            'basic': 60,     # 60 sinais/min
            'premium': 300,  # 300 sinais/min
            'enterprise': 0  # Unlimited
        }
        
    async def connect(self, websocket: WebSocket, client_id: str, api_key: str, tier: str = 'free'):
        """Aceita conexão WebSocket e registra consumidor"""
        await websocket.accept()
        
        session = ConsumerSession(
            client_id=client_id,
            api_key=api_key,
            tier=tier,
            connected_at=datetime.now(timezone.utc),
            filters={'min_liquidity': 10000, 'min_profit': 0.5} if tier == 'free' else {}
        )
        
        self.active_connections[client_id] = websocket
        self.consumer_sessions[client_id] = session
        self.metrics['total_consumers_connected'] += 1
        
        print(f"🔌 [SIGNAL_SERVER] Cliente conectado: {client_id} (tier: {tier})")
        
        # Envia handshake de boas-vindas
        await websocket.send_json({
            'event': 'CONNECTED',
            'client_id': client_id,
            'tier': tier,
            'rate_limit': self.rate_limits[tier],
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
        
    def disconnect(self, client_id: str):
        """Remove conexão ativa"""
        if client_id in self.active_connections:
            del self.active_connections[client_id]
        
        session = self.consumer_sessions.get(client_id)
        if session:
            duration = (datetime.now(timezone.utc) - session.connected_at).total_seconds()
            print(f"🔌 [SIGNAL_SERVER] Cliente desconectado: {client_id} "
                  f"(sinais: {session.signals_consumed}, duração: {duration:.0f}s)")
            
    async def broadcast_signal(self, signal: SignalPacket):
        """Transmite sinal para todos os consumidores ativos"""
        self.signal_history.append(signal)
        self.metrics['total_signals_broadcast'] += 1
        self.metrics['potential_profit_broadcast'] += signal.estimated_profit_usd
        
        # Mantém histórico limitado (últimos 1000)
        if len(self.signal_history) > 1000:
            self.signal_history.pop(0)
        
        disconnected = []
        
        for client_id, websocket in self.active_connections.items():
            session = self.consumer_sessions.get(client_id)
            if not session:
                continue
                
            # Rate limiting por tier
            if self.rate_limits[session.tier] > 0:
                if session.signals_consumed >= self.rate_limits[session.tier]:
                    continue  # Skip rate-limited consumers
            
            # Aplica filtros do consumidor
            if session.filters:
                min_liq = session.filters.get('min_liquidity', 0)
                min_profit = session.filters.get('min_profit', 0)
                if signal.liquidity_usd < min_liq or signal.estimated_profit_usd < min_profit:
                    continue
            
            try:
                await websocket.send_json(signal.to_dict())
                session.signals_consumed += 1
                session.last_signal_at = datetime.now(timezone.utc)
                self.metrics['signals_by_tier'][session.tier] += 1
                
            except Exception as e:
                disconnected.append(client_id)
                
        # Limpa conexões mortas
        for client_id in disconnected:
            self.disconnect(client_id)
            
        print(f"📡 [SIGNAL_SERVER] Sinal {signal.signal_id} → "
              f"{len(self.active_connections) - len(disconnected)} consumidores")
              
    def get_metrics(self) -> dict:
        """Retorna métricas de broadcast para Grafana/Dashboard"""
        uptime = (datetime.now(timezone.utc) - self.metrics['start_time']).total_seconds()
        return {
            'uptime_seconds': uptime,
            'active_connections': len(self.active_connections),
            'total_signals_broadcast': self.metrics['total_signals_broadcast'],
            'total_consumers_ever': self.metrics['total_consumers_connected'],
            'potential_profit_broadcast': round(self.metrics['potential_profit_broadcast'], 2),
            'signals_by_tier': self.metrics['signals_by_tier'],
            'avg_profit_per_signal': round(
                self.metrics['potential_profit_broadcast'] / max(1, self.metrics['total_signals_broadcast']), 2
            )
        }

# ═══════════════════════════════════════════════════════════════════════════════
# FASTAPI APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

# Engine global
engine = SignalBroadcastEngine()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan manager para startup/shutdown"""
    print("🚀 [SIGNAL_SERVER] Lighthouse Signal Provider iniciado")
    print("📡 [SIGNAL_SERVER] Zero-Gas Architecture Active")
    print("💰 [SIGNAL_SERVER] M2M Billing Layer Ready")
    yield
    print("🛑 [SIGNAL_SERVER] Desligando...")

app = FastAPI(
    title="GXEON Lighthouse Signal Provider",
    description="M2M Alpha Broadcast — Zero-Gas Signal Station",
    version="3.0.0",
    lifespan=lifespan
)

# CORS para integração web/dashboard
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ═══════════════════════════════════════════════════════════════════════════════
# API ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/")
async def root():
    """Status do Signal Provider"""
    return {
        "name": "GXEON Lighthouse Signal Provider",
        "version": "3.0.0",
        "architecture": "M2M_ALPHA_BROADCAST",
        "gas_constraint": "STRICT_ZERO_ETH",
        "status": "operational",
        "beneficiary": "0x3955d559055DadB7067054cB6E6f974710345224"
    }

@app.get("/health")
async def health():
    """Health check para monitoring"""
    return {
        "status": "healthy",
        "active_connections": len(engine.active_connections),
        "uptime": engine.get_metrics()['uptime_seconds']
    }

@app.get("/metrics")
async def metrics():
    """Métricas para Grafana dashboard"""
    return engine.get_metrics()

@app.get("/signals/history")
async def signal_history(limit: int = 100):
    """Histórico de sinais recentes (para debug/análise)"""
    history = engine.signal_history[-limit:]
    return {
        "count": len(history),
        "signals": [s.to_dict() for s in history]
    }

@app.websocket("/ws/signals")
async def websocket_signals(websocket: WebSocket):
    """Endpoint principal: Stream de sinais MEV em tempo real"""
    # Extrai headers de autenticação (simplificado)
    client_id = websocket.headers.get('x-client-id', f'anon_{int(time.time())}')
    api_key = websocket.headers.get('x-api-key', 'free_tier')
    
    # Determina tier baseado na API key (mock auth)
    tier_map = {
        'free_tier': 'free',
        'basic_123': 'basic',
        'premium_456': 'premium',
        'enterprise_789': 'enterprise'
    }
    tier = tier_map.get(api_key, 'free')
    
    await engine.connect(websocket, client_id, api_key, tier)
    
    try:
        while True:
            # Mantém conexão viva e escuta comandos do cliente
            data = await websocket.receive_text()
            try:
                command = json.loads(data)
                
                # Cliente pode ajustar filtros em runtime
                if command.get('action') == 'set_filters':
                    session = engine.consumer_sessions.get(client_id)
                    if session:
                        session.filters = command.get('filters', {})
                        await websocket.send_json({
                            'event': 'FILTERS_UPDATED',
                            'filters': session.filters
                        })
                        
                elif command.get('action') == 'get_stats':
                    await websocket.send_json({
                        'event': 'STATS',
                        'data': engine.get_metrics()
                    })
                    
            except json.JSONDecodeError:
                pass  # Ignora mensagens inválidas
                
    except WebSocketDisconnect:
        engine.disconnect(client_id)

@app.websocket("/ws/radar")
async def websocket_radar_input(websocket: WebSocket):
    """Endpoint para receber sinais do radar SHIX (input privado)"""
    await websocket.accept()
    print("🔌 [SIGNAL_SERVER] Radar SHIX conectado ao input stream")
    
    try:
        while True:
            data = await websocket.receive_text()
            try:
                opportunity = json.loads(data)
                
                # Converte oportunidade do radar em SignalPacket
                signal = SignalPacket(
                    signal_id=opportunity.get('id') or f"sig_{int(time.time() * 1000)}",
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    source='RADAR_SHIX',
                    opportunity_type=opportunity.get('type', 'UNKNOWN'),
                    chain=opportunity.get('chain', 'arbitrum'),
                    dex=opportunity.get('dex', 'unknown'),
                    pool_address=opportunity.get('poolAddress', ''),
                    token_a=opportunity.get('tokenA', ''),
                    token_b=opportunity.get('tokenB', ''),
                    liquidity_usd=opportunity.get('liquidityUsd', 0),
                    volume_24h=opportunity.get('volume24h', 0),
                    estimated_profit_usd=opportunity.get('profitUsd', 0),
                    confidence_score=opportunity.get('confidence', 0.7),
                    block_number=opportunity.get('blockNumber'),
                    tx_hash=opportunity.get('txHash'),
                    gas_estimate=150000,
                    priority=opportunity.get('priority', 'normal'),
                    ttl_seconds=300
                )
                
                # Broadcast para todos os consumidores
                await engine.broadcast_signal(signal)
                
            except json.JSONDecodeError:
                print(f"⚠️ [SIGNAL_SERVER] JSON inválido recebido do radar")
                
    except WebSocketDisconnect:
        print("🔌 [SIGNAL_SERVER] Radar SHIX desconectado")

# ═══════════════════════════════════════════════════════════════════════════════
# CLI ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("""
    ╔══════════════════════════════════════════════════════════════════════════╗
    ║  🌑 GXEON LIGHTHOUSE SIGNAL PROVIDER v3.0 — M2M Alpha Broadcast            ║
    ╠══════════════════════════════════════════════════════════════════════════╣
    ║  Architecture: Zero-Gas Signal Station                                 ║
    ║  Protocol: M2M_ALPHA_BROADCAST                                           ║
    ║  Endpoints: /ws/signals (consumers) | /ws/radar (input)                  ║
    ║  Metrics: /metrics | /health                                             ║
    ║  Beneficiary: 0x3955d559055DadB7067054cB6E6f974710345224               ║
    ╚══════════════════════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        "signalServer:app",
        host="0.0.0.0",
        port=8765,
        reload=False,
        log_level="info"
    )
